package com.ssafy.b209.conversation.service;

import com.ssafy.b209.auth.service.CurrentAuthenticatedUserResolver;
import com.ssafy.b209.child.domain.Child;
import com.ssafy.b209.conversation.domain.ConversationCompletionReason;
import com.ssafy.b209.conversation.domain.ConversationMessage;
import com.ssafy.b209.conversation.domain.ConversationSession;
import com.ssafy.b209.conversation.dto.EndConversationRequest;
import com.ssafy.b209.conversation.dto.EndConversationResponse;
import com.ssafy.b209.conversation.exception.ConversationEndErrorCode;
import com.ssafy.b209.conversation.repository.ConversationEndAuthorizationRepository;
import com.ssafy.b209.conversation.repository.ConversationMessageRepository;
import com.ssafy.b209.conversation.repository.ConversationSessionRepository;
import com.ssafy.b209.drawing.domain.DrawingSession;
import com.ssafy.b209.drawing.domain.DrawingStage;
import com.ssafy.b209.drawing.repository.DrawingSessionRepository;
import com.ssafy.b209.global.exception.BusinessException;
import java.time.Clock;
import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 보호자 권한과 최신 질문 상태를 확인한 뒤 대화를 종료한다.
 *
 * <p>그림 작성 중 시작된 대화는 종료 후에도 Drawing 단계를 유지한다. 그림일기의 질문 상한 종료는 새 그림 분석으로 대화를 다시 열 수 있도록 Conversing
 * 단계를 보존하고, 그 밖의 그림 완료 이후 대화는 Reflection 단계로 전환한다.
 */
@Service
public class ConversationEndService {

  private static final String ART_DIARY_CODE = "ART_DIARY";

  private final CurrentAuthenticatedUserResolver currentUserResolver;
  private final ConversationEndAuthorizationRepository authorizationRepository;
  private final ConversationSessionRepository conversationRepository;
  private final DrawingSessionRepository drawingRepository;
  private final ConversationMessageRepository messageRepository;
  private final ConversationEventRecorder eventRecorder;
  private final Clock clock;

  /**
   * 운영 환경의 UTC 시간을 사용하는 대화 종료 서비스를 구성한다.
   *
   * @param currentUserResolver 현재 인증된 보호자 식별자 조회기
   * @param authorizationRepository 대화 접근 권한 조회 저장소
   * @param conversationRepository 대화 세션 잠금 조회 저장소
   * @param drawingRepository 연결된 그림 세션 잠금 조회 저장소
   * @param messageRepository 최신 질문 조회 저장소
   * @param eventRecorder 대화 행동 이벤트 적재기
   */
  @Autowired
  public ConversationEndService(
      CurrentAuthenticatedUserResolver currentUserResolver,
      ConversationEndAuthorizationRepository authorizationRepository,
      ConversationSessionRepository conversationRepository,
      DrawingSessionRepository drawingRepository,
      ConversationMessageRepository messageRepository,
      ConversationEventRecorder eventRecorder) {
    this(
        currentUserResolver,
        authorizationRepository,
        conversationRepository,
        drawingRepository,
        messageRepository,
        eventRecorder,
        Clock.systemUTC());
  }

  ConversationEndService(
      CurrentAuthenticatedUserResolver currentUserResolver,
      ConversationEndAuthorizationRepository authorizationRepository,
      ConversationSessionRepository conversationRepository,
      DrawingSessionRepository drawingRepository,
      ConversationMessageRepository messageRepository,
      ConversationEventRecorder eventRecorder,
      Clock clock) {
    this.currentUserResolver = currentUserResolver;
    this.authorizationRepository = authorizationRepository;
    this.conversationRepository = conversationRepository;
    this.drawingRepository = drawingRepository;
    this.messageRepository = messageRepository;
    this.eventRecorder = eventRecorder;
    this.clock = clock;
  }

  /**
   * 현재 보호자가 접근 가능한 진행 중 대화를 종료하고 연결된 그림 세션의 후속 단계를 확정한다.
   *
   * <p>이미 종료된 대화는 최초 완료 사유와 시각을 바꾸지 않고 같은 종료 결과를 반환한다. 마지막 질문 식별자가 전달되면 잠금 안에서 최신 질문과 비교해 오래된 화면
   * 상태로 인한 종료를 차단한다. 그림 작성 또는 최종 분석 중 종료하면 해당 단계를 유지한다. 그림일기 질문 상한 종료는 새 분석 기반 재개를 위해 Conversing
   * 단계를 보존하며, 나머지 그림 완료 이후 대화는 Reflection으로 전환한다.
   *
   * @param conversationId 종료할 대화 세션 식별자
   * @param request 종료 사유와 마지막 질문 식별자
   * @return 저장된 대화 종료 상태와 다음 그림 활동 단계
   * @throws BusinessException 접근할 수 없거나 대화·그림 세션이 없고, 최신 질문 또는 상태가 맞지 않는 경우
   */
  @Transactional
  public EndConversationResponse end(Long conversationId, EndConversationRequest request) {
    Long guardianUserId = currentUserResolver.requireUserId();
    if (!authorizationRepository.hasConversationAccess(guardianUserId, conversationId)) {
      throw new BusinessException(ConversationEndErrorCode.CONVERSATION_NOT_FOUND);
    }

    ConversationSession conversation =
        conversationRepository
            .findByIdForUpdate(conversationId)
            .orElseThrow(
                () -> new BusinessException(ConversationEndErrorCode.CONVERSATION_NOT_FOUND));

    DrawingSession drawingSession =
        drawingRepository
            .findNotDeletedByIdForUpdate(conversation.getDrawingSessionId())
            .orElseThrow(
                () -> new BusinessException(ConversationEndErrorCode.CONVERSATION_NOT_FOUND));

    if (conversation.isCompleted()) {
      return toResponse(conversation, drawingSession.getCurrentStage());
    }

    validateLastQuestion(conversation.getId(), request.lastQuestionMessageId());
    if (!conversation.isConversing()) {
      throw new BusinessException(ConversationEndErrorCode.CONVERSATION_NOT_CONVERSING);
    }

    conversation.complete(request.reason(), LocalDateTime.now(clock));
    recordEnded(conversation, drawingSession, request);
    DrawingStage nextStage = drawingSession.getCurrentStage();
    if ((nextStage == DrawingStage.CONVERSING || nextStage == DrawingStage.REFLECTION)
        && !shouldKeepArtDiaryOpen(drawingSession, request.reason())) {
      drawingSession.enterReflection();
      nextStage = DrawingStage.REFLECTION;
    }
    return toResponse(conversation, nextStage);
  }

  private boolean shouldKeepArtDiaryOpen(
      DrawingSession drawingSession, ConversationCompletionReason completionReason) {
    return completionReason == ConversationCompletionReason.QUESTION_LIMIT_REACHED
        && drawingSession.getDrawingType() != null
        && ART_DIARY_CODE.equals(drawingSession.getDrawingType().getCode());
  }

  /**
   * 대화 종료를 행동 이벤트로 남긴다 (S15P11B209-973).
   *
   * <p>이미 종료된 대화는 위에서 그대로 반환하고 여기 오지 않으므로 종료 이벤트는 대화당 한 번만 남는다.
   *
   * <p>아동을 확정하지 못하면 기록을 건너뛴다. 여기까지 왔다는 것은 종료가 이미 성립했다는 뜻이라, 관측용 좌표가 비었다고 종료 응답을 실패로 만들 이유가 없다.
   *
   * @param conversation 방금 종료한 대화 세션
   * @param drawingSession 연결된 그림 활동 세션
   * @param request 종료 요청
   */
  private void recordEnded(
      ConversationSession conversation,
      DrawingSession drawingSession,
      EndConversationRequest request) {
    Child child = drawingSession.getChild();
    if (child == null || child.getId() == null) {
      return;
    }
    eventRecorder.recordSessionEnd(
        new ConversationEventContext(
            conversation.getId(), child.getId(), conversation.getDrawingSessionId()),
        request.reason().name(),
        conversation.getQuestionCount());
  }

  private void validateLastQuestion(Long conversationId, Long lastQuestionMessageId) {
    if (lastQuestionMessageId == null) {
      return;
    }

    ConversationMessage latestQuestion =
        messageRepository
            .findFirstByConversationSessionIdAndMessageTypeOrderByMessageSequenceDesc(
                conversationId, "QUESTION")
            .orElseThrow(
                () ->
                    new BusinessException(
                        ConversationEndErrorCode.CONVERSATION_LAST_QUESTION_MISMATCH));
    if (!lastQuestionMessageId.equals(latestQuestion.getId())) {
      throw new BusinessException(ConversationEndErrorCode.CONVERSATION_LAST_QUESTION_MISMATCH);
    }
  }

  private EndConversationResponse toResponse(
      ConversationSession conversation, DrawingStage nextStage) {
    return new EndConversationResponse(
        conversation.getId(),
        conversation.getConversationStatus(),
        conversation.isCompleted(),
        conversation.getCompletionReason(),
        conversation.getCompletedAt(),
        nextStage);
  }
}
